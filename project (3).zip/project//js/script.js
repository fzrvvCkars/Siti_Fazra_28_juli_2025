 document.getElementById("LoginForm").addEventListener('submit',function(event) {
        event.preventDefault();
        
        var Username = document.getElementById('Username').value;
        var password = document.getElementById('password').value;
        var errorMessage = document.getElementById('error-message');
        
        if (Username === '' || password === ''){
            errorMessage.textContent = 'ISI DEK!!!';
        
        } else if (Username !== 'fazra' || password !=='123') {
            errorMessage.textContent = 'username atau password salah, masukan lagi';
        } else {
            errorMessage.textContent = ''
            alert('login berhasil');
        }
        
      } );